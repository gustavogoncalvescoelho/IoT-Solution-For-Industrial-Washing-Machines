(typeof window === 'undefined' ? global : window).MG = {version: '2.11'};
